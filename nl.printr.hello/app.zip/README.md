### Sample Homey App

This is a demo app. It can do the following:

1. Listen to speech
2. Control the LED ring
3. Show a card on the mobile phone
4. Expose a settings screen
5. Expose a few Flow Editor cards
6. Register a virtual light bulb (driver)

Load this app in your Homey Devkit to explore its contents!